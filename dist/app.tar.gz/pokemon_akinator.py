import flet as ft
import pandas as pd
import numpy as np

class Akinator:
    def __init__(self, df, name="name", beta=1):
        self.beta = beta

        self.items = list(df[name])
        self.questions_all = list(df.columns[df.dtypes == bool])
        self.df_qa = df[self.questions_all].astype(int) * 2 - 1
        self.df_qa.index = self.items

        self.n_item = len(self.items)
        self.n_question = len(self.questions_all)
        self.hamiltonians = np.zeros(self.n_item)
        self.answers = [-1, -0.5, 0, +0.5, +1]

        self.questions_hist = []
        self.ansers_hist = []
        self.ng_items = set()

    def get_prob(self):
        prob = np.exp(-self.beta * self.hamiltonians)
        prob = prob / np.sum(prob)
        return prob

    def update(self, q, a):
        self.questions_hist.append(q)
        self.ansers_hist.append(a)
        self.hamiltonians += (
            np.array(self.df_qa.iloc[:, q], dtype=np.float32) - a
        ) ** 2

    def next_question(self):
        qs = set(np.arange(self.n_question)) - set(self.questions_hist)
        q = max(qs, key=self.score)
        return q

    def score(self, q):
        gammas = np.array([self.gamma(q, a) for a in self.answers])
        return -np.sum(gammas * np.log(gammas))

    def gamma(self, q, a):
        alpha = np.array(self.df_qa.iloc[:, q])
        H = self.hamiltonians + (alpha - a) ** 2
        return np.sum(np.exp(-self.beta * H))

    def ng_item(self, i):
        self.hamiltonians[i] = 10000
        self.ng_items.add(i)

    def reset(self):
        self.hamiltonians = np.zeros(self.n_item)
        self.questions_hist = []
        self.ansers_hist = []


def main(page: ft.Page):
    def answer_view():
        def on_click_answer_yes(id_poke):
            akinator.reset()
            page.go("/question")

        def on_click_answer_no(id_poke):
            akinator.ng_item(id_poke)
            page.go("/question")

        ps = akinator.get_prob()
        id_poke = max(list(range(len(ps))), key=lambda x: ps[x])
        name_poke = akinator.items[id_poke]
        img_poke = f"http://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/{id_poke+1}.png"

        # アーキド博士
        ui_img = ft.Row(
            [
                ft.Image(
                    src="https://i.imgur.com/eBIefxM.png",
                    width=200,
                    height=200,
                    fit=ft.ImageFit.CONTAIN,
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )

        # 質問
        ui_top_text = ft.Row(
            [
                ft.Text(
                    f"思い浮かべているのは｢{name_poke}｣ですか?",
                    style=ft.TextThemeStyle.DISPLAY_MEDIUM,
                ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )

        # ポケモン画像
        ui_img_poke = ft.Row(
            [
                ft.Image(
                    src=img_poke,
                    width=200,
                    height=200,
                    fit=ft.ImageFit.CONTAIN,
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )

        # 回答
        a_1 = ft.Row(
            [ft.TextButton(text="はい", on_click=lambda _: on_click_answer_yes(id_poke))],
            alignment=ft.MainAxisAlignment.CENTER,
        )
        a_2 = ft.Row(
            [ft.TextButton(text="いいえ", on_click=lambda _: on_click_answer_no(id_poke))],
            alignment=ft.MainAxisAlignment.CENTER,
        )

        return ft.View(
            "/answe",
            [ui_img, ui_top_text, ui_img_poke, a_1, a_2],
        )

    def question_view():
        def on_click_question(a, q):
            akinator.update(q, a)
            prob = max(akinator.get_prob())
            if prob < 0.8:
                page.go("")
                page.go("/question")
            else:
                page.go("/answer")

        # アーキド博士
        ui_img = ft.Row(
            [
                ft.Image(
                    src="https://i.imgur.com/eBIefxM.png",
                    width=200,
                    height=200,
                    fit=ft.ImageFit.CONTAIN,
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )

        # 質問
        q = akinator.next_question()
        q_text = akinator.questions_all[q]
        q_number = len(akinator.questions_hist) + 1
        ui_top_text = ft.Row(
            [
                ft.Text(
                    f"q{q_number}.{q_text}",
                    style=ft.TextThemeStyle.DISPLAY_MEDIUM,
                ),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )

        # 回答
        a_1 = ft.Row(
            [ft.TextButton(text="はい", on_click=lambda _: on_click_question(1, q))],
            alignment=ft.MainAxisAlignment.CENTER,
        )
        a_2 = ft.Row(
            [ft.TextButton(text="いいえ", on_click=lambda _: on_click_question(-1, q))],
            alignment=ft.MainAxisAlignment.CENTER,
        )
        a_3 = ft.Row(
            [ft.TextButton(text="分からない", on_click=lambda _: on_click_question(0, q))],
            alignment=ft.MainAxisAlignment.CENTER,
        )
        a_4 = ft.Row(
            [
                ft.TextButton(
                    text="たぶんそう部分的にそう", on_click=lambda _: on_click_question(0.5, q)
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )
        a_5 = ft.Row(
            [
                ft.TextButton(
                    text="たぶん違う そうでもない", on_click=lambda _: on_click_question(-0.5, q)
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )

        return ft.View(
            "/question",
            [ui_img, ui_top_text, a_1, a_2, a_3, a_4, a_5],
        )

    def route_change(handler):
        troute = ft.TemplateRoute(handler.route)
        # page.views.clear()
        if troute.match("/question"):
            page.views.append(question_view())
        elif troute.match("/answer"):
            page.views.append(answer_view())

    page.title = "pokemon akinator"
    page.on_route_change = route_change
    page.go("/question")


akinator = Akinator(pd.read_csv("polemon_qa.csv"))
ft.app(target=main)
